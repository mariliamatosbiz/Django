from django.contrib import admin

from .models import Questao

admin.site.register(Questao)

# Register your models here.
