from django.apps import AppConfig


class VotacoesConfig(AppConfig):
    name = 'votacoes'
